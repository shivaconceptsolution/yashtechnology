from django.shortcuts import render
from django.http import HttpResponse

def index(request):
  if request.method=="POST":
    a = request.POST["txtnum1"]
    b = request.POST["txtnum2"]
    c = int(a)+int(b)
    return render(request,"additionapp/index.html",{"key":"result is "+str(c)})
  else:
     return render(request,"additionapp/index.html")  

def fact(request):
    return render(request,"additionapp/fact.html")


def factlogic(request):
    num = int(request.POST["txtnum"])
    f=1
    for i in range(num,1,-1):
        f=f*i

    return HttpResponse("Result is "+str(f))

def prime(request):
   return render(request,"additionapp/prime.html")


def primelogic(request):
   num = int(request.POST["txtnum"])
   c=0
   s=''
   for i in range(1,num+1):
      if num%i==0:
         c=c+1
   if c==2:
       s = 'prime'
   else:
       s = 'not prime'    
         
   return render(request,"additionapp/prime.html",{'n':num,'key':s})

def fibo(request):
    return render(request,"additionapp/fibo.html")

def fibologic(request):
    num = int(request.POST["txtnum"])
    a=-1
    b=1
    s= ''
    for i in range(1,num):
       c=a+b
       s= s+str(c) +" "
       a=b
       b=c

    return render(request,"additionapp/fibo.html",{'key':s})
    
def complex(request):
   return render(request,"additionapp/complex.html")

def complexlogic(request):
  a= request.POST["txtnum1"]
  b = request.POST["txtnum2"]
  d = a.find("+")
  e = a.find("j")
  d1 = b.find("+")
  e1 = b.find("j")
  r1 = a[0:d]
  i1 = a[d:e]
  r2 = b[0:d1]
  i2 = b[d1:e1]
  r = int(r1)+int(r2)
  i = int(i1)+int(i2)
  c = str(r) + "+" + str(i) + "j"

  return render(request,"additionapp/complex.html",{"key":c})    

def calc(request):
   if request.method=="POST":
        a= int(request.POST["txtnum1"])
        b= int(request.POST["txtnum2"])

        c=0
        if request.POST["btnsubmit"]== "+":

           c=a+b
           print("hello",c) 
        elif request.POST["btnsubmit"]=="-":
           c=a-b	
        elif request.POST["btnsubmit"]=='*':
           c=a*b
        else:
           c=a/b
        return render(request,"additionapp/calc.html",{"key":str(c)})            


   else:
       return render(request,"additionapp/calc.html")
