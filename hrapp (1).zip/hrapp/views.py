from django.shortcuts import render
from .models import Reg

def index(request):
    if request.method=="POST":
        obj = Reg(username=request.POST["txtuser"],password=request.POST["txtpass"],role=request.POST["txtrole"],fname=request.POST["txtfname"])
        obj.save()
        return render(request,"hrapp/index.html",{"key":'reg successfully'})
    return render(request,"hrapp/index.html")

def about(request):
	return render(request,"hrapp/about.html")

def contact(request):
	return render(request,"hrapp/contact.html")